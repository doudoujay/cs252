#!/bin/bash
#delcare STRING variable
STRING="Hello World"
#print variable on a screen
echo $STRING
