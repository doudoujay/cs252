#!/bin/bash
echo $1 $2 $3
