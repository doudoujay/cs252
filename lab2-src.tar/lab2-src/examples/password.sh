#!/bin/bash
echo Error: Password length invalid.
