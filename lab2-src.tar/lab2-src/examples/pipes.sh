#!/bin/bash
echo "Retrieving data about" $USER
who | grep $USER
